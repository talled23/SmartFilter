<?php
    //echo "connected!";

    $selected = filter_input(INPUT_POST, "selected");

    $event_id = filter_input(INPUT_POST, "event_id");

    $data = "artem";
    
    //echo $data;


?>